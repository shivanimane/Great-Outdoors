package com.greatoutdoor.loginmicroservice.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;






@Service
public class AdminService {
	private RestTemplate rest = new RestTemplate();

	



}
