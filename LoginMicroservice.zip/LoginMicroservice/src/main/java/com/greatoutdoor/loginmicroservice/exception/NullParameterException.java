
/**
 * 
 */
package com.greatoutdoor.loginmicroservice.exception;

/**
 * @author Shivani

 *
 */
public class NullParameterException extends RuntimeException{

	/**
	 * 
	 */
	public NullParameterException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	
	public NullParameterException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public NullParameterException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

public NullParameterException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


	public NullParameterException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	

}
	

