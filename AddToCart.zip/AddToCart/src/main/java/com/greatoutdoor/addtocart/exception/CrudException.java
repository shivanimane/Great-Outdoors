/**
 * 
 */
package com.greatoutdoor.addtocart.exception;

/**
 * @author Shivani

 *
 */
public class CrudException extends RuntimeException{
	/**
	 * 
	 */
	public CrudException(String message) {
		super(message);
	}

}
