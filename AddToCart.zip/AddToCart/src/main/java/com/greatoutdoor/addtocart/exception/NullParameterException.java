/**
 * 
 */
package com.greatoutdoor.addtocart.exception;

/**
 * @author Shivani

 *
 */
public class NullParameterException extends RuntimeException{

	/**
	 * 
	 */
	public NullParameterException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public NullParameterException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
