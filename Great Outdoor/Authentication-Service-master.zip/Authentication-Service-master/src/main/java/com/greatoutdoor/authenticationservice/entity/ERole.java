package com.greatoutdoor.authenticationservice.entity;

public enum ERole {
	ROLE_USER,
    ROLE_PRODUCT_MASTER,
    ROLE_ADMIN,
    ROLE_RETAILER
}
